import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:study_buddy/screens/home/components/app_bar.dart';
import 'package:study_buddy/firebase_messaging_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'components/background.dart';

class HomePage extends StatefulWidget {
  HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final User? user = FirebaseAuth.instance.currentUser;
  String _city = "Detecting location...";

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  /// פונקציה לאיתור מיקום המשתמש והצגת שם העיר
  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // בדיקת האם שירותי מיקום מופעלים
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        _city = "Location services are disabled.";
      });
      return;
    }

    // בדיקת האם יש הרשאה למיקום
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          _city = "Location permission denied.";
        });
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() {
        _city = "Location permissions are permanently denied.";
      });
      return;
    }

    // קבלת המיקום של המשתמש
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    _getCityFromCoordinates(position.latitude, position.longitude);
  }

  /// פונקציה להמרת קואורדינטות לשם עיר
  Future<void> _getCityFromCoordinates(double lat, double lon) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lon);
      if (placemarks.isNotEmpty) {
        setState(() {
          _city = placemarks.first.locality ?? "Unknown location";
        });

        // שליחת התראה מבוססת מיקום
        if (_city == "Tel Aviv") {
          FirebaseMessagingService().showLocalNotification(
            RemoteMessage(
                notification: RemoteNotification(
              title: "Welcome to Tel Aviv!",
              body: "Check out new courses available in your area! 📚",
            )),
          );
        }
      }
    } catch (e) {
      setState(() {
        _city = "Failed to get location";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(user?.photoURL, context),
      body: Stack(
        children: [
          const BackgroundWithImages(),
          const SizedBox(
            height: double.infinity,
            width: double.infinity,
          ),
          Container(
            height: double.infinity,
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  user != null
                      ? 'Welcome, ${user!.displayName}!'
                      : 'Welcome to Study Buddy!',
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 185, 119, 211),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "You are in: $_city",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/my_courses'),
                  child: const Text('My Courses'),
                  style: ElevatedButton.styleFrom(
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(35),
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/courses'),
                  child: const Text('View All Courses'),
                  style: ElevatedButton.styleFrom(
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(45),
                  ),
                ),
                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
